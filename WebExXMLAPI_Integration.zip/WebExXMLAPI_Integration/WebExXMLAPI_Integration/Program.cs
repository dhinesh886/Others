﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Net;
using System.Security.Authentication;
using System.Security.Claims;
using System.Text;

namespace WebExXMLAPI_Integration
{
    class Program
    {
        /// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
        public static void Main(string[] args)
        {
            var token = "NjQ3ODhiOWUtYjRmZC00ODIyLWI5ZTUtNGFjNDE2ZjhjYmZmNjcyZWQ0NjgtMGRm_PF84_consumer";
            string strXMLServer = "https://api.webex.com/WBXService/XMLService";
            const SslProtocols _Tls12 = (SslProtocols)0x00000C00;
            const SecurityProtocolType Tls12 = (SecurityProtocolType)_Tls12;
            ServicePointManager.SecurityProtocol = Tls12;
            WebRequest request = WebRequest.Create(strXMLServer);

            // Set the Method property of the request to POST.
            request.Method = "POST";
            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";

            // Create POST data and convert it to a byte array.
            //var strXML = CreateMeetingXML();
            var strXML = CreateMeetingXML(token);

            byte[] byteArray = Encoding.UTF8.GetBytes(strXML);

            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;

            // Get the request stream.
            Stream dataStream = request.GetRequestStream();
            // Write the data to the request stream.
            dataStream.Write(byteArray, 0, byteArray.Length);
            // Close the Stream object.
            dataStream.Close();
            // Get the response.
            WebResponse response = request.GetResponse();

            // Get the stream containing content returned by the server.
            dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);
            // Read the content.
            string responseFromServer = reader.ReadToEnd();
            // Display the content.
            Console.WriteLine(responseFromServer);
            // Clean up the streams.
            reader.Close();
            dataStream.Close();
            response.Close();

        }
        private static string CreateMeetingXML()
        {
            string strXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" +
                "<serv:message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n    " +
                "<header>\r\n        " +
                        "<securityContext>\r\n            " +
                            "<siteName>meetingsapac12</siteName>\r\n            " +
                            "<webExID>dhinesh886@gmail.com</webExID>\r\n            " +
                            "<password>Login1-2</password>\r\n        " +
                        //"<webExAccessToken>"+token+"</webExAccessToken>" +
                        "</securityContext>\r\n    " +
             "</header>\r\n    " +
 "<body>\r\n        " +
 "<bodyContent\r\n            " +
 "xsi:type=\"java:com.webex.service.binding.meeting.CreateMeeting\">\r\n            " +
 "<accessControl>\r\n                " +
 "<meetingPassword>!@#Pa44ss123</meetingPassword>\r\n            " +
 "</accessControl>\r\n            " +
 "<metaData>\r\n                " +
 "<confName>Sample Meeting</confName>\r\n                " +
// "<meetingType>1</meetingType>\r\n                " +
 "<agenda>Test</agenda>\r\n            " +
 "</metaData>\r\n            " +
 "<participants>\r\n                " +
 "<maxUserNumber>4</maxUserNumber>\r\n                " +
 "<attendees>\r\n                    " +
 "<attendee>\r\n                        " +
 "<person>\r\n                            " +
 "<name>James Kirk</name>\r\n                            " +
 "<email>dhineshkumar.m@nfp.com.com</email>\r\n                        " +
 "</person>\r\n                    " +
 "</attendee>\r\n                " +
 "</attendees>\r\n            " +
 "</participants>\r\n            " +
 "<enableOptions>\r\n                " +
 "<chat>true</chat>\r\n                " +
 "<poll>true</poll>\r\n                " +
 "<audioVideo>true</audioVideo>\r\n                " +
 "<supportE2E>TRUE</supportE2E>\r\n                " +
 "<autoRecord>TRUE</autoRecord>\r\n            " +
 "</enableOptions>\r\n            " +
 "<schedule>\r\n                " +
 "<startDate>05/31/2020 10:10:10</startDate>\r\n                " +
 "<openTime>900</openTime>\r\n                " +
 "<joinTeleconfBeforeHost>true</joinTeleconfBeforeHost>\r\n                " +
 "<duration>20</duration>\r\n                " +
 "<timeZoneID>4</timeZoneID>\r\n            " +
 "</schedule>\r\n            " +
 "<telephony>\r\n                " +
 "<telephonySupport>CALLIN</telephonySupport>\r\n                " +
 "<extTelephonyDescription>\r\n                    " +
 "Call 1-800-555-1234, Passcode 98765\r\n                " +
 "</extTelephonyDescription>\r\n            " +
 "</telephony>\r\n        " +
 "</bodyContent>\r\n    " +
 "</body>\r\n" +
 "</serv:message>\r\n";
            return strXML;
        }
        private static string CreateMeetingXML(string token)
        {

            string strXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" +
               "<serv:message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n    " +
               "<header>\r\n        " +
                       "<securityContext>\r\n            " +
                           "<siteName>meetingsapac12</siteName>\r\n            " +
                           "<webExID>dhinesh886@gmail.com</webExID>\r\n            " +
                           //"<password>Login1-2</password>\r\n        " +
                       "<webExAccessToken>"+token+"</webExAccessToken>" +
                       "</securityContext>\r\n    " +
            "</header>\r\n    " +
"<body>\r\n        " +
"<bodyContent\r\n            " +
"xsi:type=\"java:com.webex.service.binding.meeting.CreateMeeting\">\r\n            " +
"<accessControl>\r\n                " +
"<meetingPassword>!@#Pa44ss123</meetingPassword>\r\n            " +
"</accessControl>\r\n            " +
"<metaData>\r\n                " +
"<confName>Sample Meeting</confName>\r\n                " +
// "<meetingType>1</meetingType>\r\n                " +
"<agenda>Test</agenda>\r\n            " +
"</metaData>\r\n            " +
"<participants>\r\n                " +
"<maxUserNumber>4</maxUserNumber>\r\n                " +
"<attendees>\r\n                    " +
"<attendee>\r\n                        " +
"<person>\r\n                            " +
"<name>James Kirk</name>\r\n                            " +
"<email>dhineshkumar.m@nfp.com.com</email>\r\n                        " +
"</person>\r\n                    " +
"</attendee>\r\n                " +
"</attendees>\r\n            " +
"</participants>\r\n            " +
"<enableOptions>\r\n                " +
"<chat>true</chat>\r\n                " +
"<poll>true</poll>\r\n                " +
"<audioVideo>true</audioVideo>\r\n                " +
"<supportE2E>TRUE</supportE2E>\r\n                " +
"<autoRecord>TRUE</autoRecord>\r\n            " +
"</enableOptions>\r\n            " +
"<schedule>\r\n                " +
"<startDate>05/31/2020 10:10:10</startDate>\r\n                " +
"<openTime>900</openTime>\r\n                " +
"<joinTeleconfBeforeHost>true</joinTeleconfBeforeHost>\r\n                " +
"<duration>20</duration>\r\n                " +
"<timeZoneID>4</timeZoneID>\r\n            " +
"</schedule>\r\n            " +
"<telephony>\r\n                " +
"<telephonySupport>CALLIN</telephonySupport>\r\n                " +
"<extTelephonyDescription>\r\n                    " +
"Call 1-800-555-1234, Passcode 98765\r\n                " +
"</extTelephonyDescription>\r\n            " +
"</telephony>\r\n        " +
"</bodyContent>\r\n    " +
"</body>\r\n" +
"</serv:message>\r\n";
            return strXML;
        }

        private static string AuthorizeApp()
        {
            var Secret = "D9LREUAZCSXDKVIM1P7M547KO4IX0RWJAJ8N5SMRBF16O9M7ANOSFN16M7NVR4X4LW9OAN7ZN4JM9P39YL4DC9A090Q49FRINYK9FWAMX6ZSGQMQVJLOII94PSTLMX3XPICXB1IW7GT6HVI3YZ8U55XYQ0J9NH94R56RAY2D7O58K2DFZGD9LPB8C1LX0E4JCU60WS43SKBY9O5JIJOJ7HZD73OWRBCJO7A1Y1MZMNV2UIHMASVA8OXZKEJ8OLM75G4EOQ5IAQVY783UQAELFSPOAOFWGJF4W6R9108PDEEFRVOFQ9IHACL59VNJJFWHSWY5NZO9XV54QSTULVML4R";
            var Key = "2588d6a3-b064-4df9-b222-ee2bb69367fc";
            var securityKey = new SymmetricSecurityKey(Encoding.Default.GetBytes(Secret));

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(new[]
    {
        new Claim("apiKey", Key),
        new Claim("aud","dhinesh886@gmail.com"),
        new Claim("iss","https://api.webex.com/gapi/registerapikey"),
         
    });

            DateTime expires = DateTime.UtcNow.Date.AddMonths(2);
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateJwtSecurityToken(subject: claimsIdentity,
                expires: expires, signingCredentials: credentials, notBefore: DateTime.UtcNow.AddMinutes(-1), issuedAt: DateTime.UtcNow.AddMinutes(-1));

            return tokenHandler.WriteToken(token);

        }
    }
} 