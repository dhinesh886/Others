﻿
CREATE PROCEDURE [dbo].[SP_SaveTransfer]
	-- Add the parameters for the stored procedure here
	@source		varchar(50),
	@dest	    varchar(50),
	@amount 	varchar(50),
	@status		int OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	 SET @status=0;
INSERT INTO Transfers
           (source,dest,amount)
     VALUES
           (@source,@dest,@amount)

		   SET @status=1;

END