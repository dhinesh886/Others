﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CSRF.Models
{
    public class Transfers
    {
        private static string strCon = "Data Source=(localdb)\\MSSQLLocalDB;Integrated Security = True";

        public string Id { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public string Amount { get; set; }

        public string Time { get; set; }



        public int SaveTransfer(string Source, string Destination, string Amount)
        {
                int intSaveStatus = 0;
                // using (SqlConnection connection = new SqlConnection(_configuration.GetValue<string>("ConnectionString")))
                using (SqlConnection connection = new SqlConnection(strCon))
                {
                    connection.Open();

                    //string strQuery = $"SELECT * FROM login_details WHERE username = @username AND password=@password";

                    SqlCommand command = new SqlCommand("SP_SaveTransfer", connection);
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@source", Source);
                    command.Parameters.AddWithValue("@dest", Destination);
                    command.Parameters.AddWithValue("@amount", Amount);
                    command.Parameters.Add("@status", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.Output;

                    command.ExecuteNonQuery();

                    intSaveStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                }


                return intSaveStatus;
            }

        
        public List<Transfers> GetTransferDetails()
        {
            List<Transfers> lstTransfers = new List<Transfers>();
            using (SqlConnection connection = new SqlConnection(strCon))
            {

                connection.Open();
                string strQuery = $"SELECT * FROM Transfers order by timestmp desc";
                SqlCommand command = new SqlCommand(strQuery, connection);

                using (var reader = command.ExecuteReader())
                {
                    int i = 0;
                    while (reader.Read())
                    {
                        Transfers objTransfer = new Transfers();
                        objTransfer.Id = reader["id"].ToString();
                        objTransfer.Source = reader["source"].ToString();
                        objTransfer.Destination = reader["dest"].ToString();
                        objTransfer.Amount = reader["amount"].ToString();
                        objTransfer.Time = reader["timestmp"].ToString();
                        //returnString += $"Name : {reader["Name"]}. ";
                        //returnString += $"Description : {reader["Description"]}";
                        lstTransfers.Add(objTransfer);
                    }

                }
            }

            return lstTransfers;
        }
       
    }
}
