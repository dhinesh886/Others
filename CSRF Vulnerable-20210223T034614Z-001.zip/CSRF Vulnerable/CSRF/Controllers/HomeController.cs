﻿using CSRF.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CSRF.Controllers
{
    
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        
        
        // [Route("transaction/transfer")]
        [Route("home/transfer/{Source}/{Destination}/{Amount}")]
        
        
       
        public string TransferAmountGet(string Source, string Destination,string Amount)
        {
            string strReturn = "";
            int intStatus = new Transfers().SaveTransfer(Source, Destination, Amount);

            if (intStatus == 1)
                strReturn = "Tranferred Successfully";
            else
                strReturn = "Tranfer Failed !!!!";
            return strReturn;

        }


       
        [HttpGet]
        public ViewResult TransferAmount()
        {
            //return View();
            return View();
        }

        
        // [Route("transaction/transfer")]
        //[Route("home/transfer/{Source}/{Destination}/{Amount}")]
        
        public string TransferAmountPost(string Source, string Destination, string Amount)
        {
            string strReturn = "";
            int intStatus = new Transfers().SaveTransfer(Source, Destination, Amount);

            if (intStatus == 1)
                strReturn = "Tranferred Successfully";
            else
                strReturn = "Tranfer Failed !!!!";
            return strReturn;

        }

      

        [Route("transfers/view")]
        public ViewResult ViewTransfers()
        {
            List<Transfers> lstTranfers = new List<Transfers>();
            lstTranfers = new Transfers().GetTransferDetails();

            return View(lstTranfers);
        }





        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
