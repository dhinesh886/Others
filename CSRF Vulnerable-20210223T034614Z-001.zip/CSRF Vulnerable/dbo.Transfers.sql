﻿CREATE TABLE [dbo].[Transfers] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [source]   VARCHAR (50)  NOT NULL,
    [dest]     VARCHAR (50)  NOT NULL,
    [Amount]   VARCHAR (100) NOT NULL,
    [timestmp] DATETIME      DEFAULT (getdate()) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

