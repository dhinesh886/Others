﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace XSS.Models
{
    public class Message
    {
        private static string strCon1 = "Server=.;Database=CORESecurity;Integrated Security = true";
        private static string strCon = "Data Source=(localdb)\\MSSQLLocalDB;Integrated Security = True";

        public string Id { get; set; }

        
        public string Name { get; set; }

        
        public string EmailId { get; set; }

        public string MessageText { get; set; }

        public string SaveStatus { get; set; }


        public int SaveMessage(Message objMessage)
        {
            int intSaveStatus = 0;
            using (SqlConnection connection = new SqlConnection(strCon))
            {
                connection.Open();

               
                SqlCommand command = new SqlCommand("SP_SaveMessage", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@name", objMessage.Name);
                command.Parameters.AddWithValue("@email", objMessage.EmailId);
                command.Parameters.AddWithValue("@message", objMessage.MessageText);
                command.Parameters.Add("@status", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.Output;

                command.ExecuteNonQuery();

                intSaveStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
            }


            return intSaveStatus;
        }


        public List<Message> GetMessages(string id)
        {
            List<Message> lstMessage = new List<Message>();

            using (SqlConnection connection = new SqlConnection(strCon))
            {

                connection.Open();
                string strQuery = "";
                if (id == "0")
                    strQuery = $"SELECT Top 1 * FROM MessageDetails order by id desc";
                else
                    strQuery = $"SELECT * FROM MessageDetails WHERE id = '" + id + "'";
                SqlCommand command = new SqlCommand(strQuery, connection);

                using (var reader = command.ExecuteReader())
                {
                    int i = 0;
                    while (reader.Read())
                    {
                        Message objMessage = new Message();
                        //string returnString = string.Empty;
                        objMessage.Id = reader["id"].ToString();
                        objMessage.Name = reader["name"].ToString();
                        objMessage.EmailId = reader["email"].ToString();
                        objMessage.MessageText = reader["message"].ToString();

                        //returnString += $"Name : {reader["Name"]}. ";
                        //returnString += $"Description : {reader["Description"]}";
                        lstMessage.Add(objMessage);
                    }

                }
            }

            return lstMessage;
        }
        public List<Message> GetMessagesByUserName(string username)
        {
            List<Message> lstMessage = new List<Message>();

            using (SqlConnection connection = new SqlConnection(strCon))
            {

                connection.Open();
                string strQuery = "";
                if (username == "ALL")
                    strQuery = $"SELECT * FROM MessageDetails ";
                else
                    strQuery = $"SELECT * FROM MessageDetails WHERE name = '" + username + "'";
                SqlCommand command = new SqlCommand(strQuery, connection);

                using (var reader = command.ExecuteReader())
                {
                    int i = 0;
                    while (reader.Read())
                    {
                        Message objMessage = new Message();
                        //string returnString = string.Empty;
                        objMessage.Name = reader["name"].ToString();
                        objMessage.EmailId = reader["email"].ToString();
                        objMessage.MessageText = reader["message"].ToString();

                        //returnString += $"Name : {reader["Name"]}. ";
                        //returnString += $"Description : {reader["Description"]}";
                        lstMessage.Add(objMessage);
                    }

                }
            }

            return lstMessage;
        }


       
    }
}
