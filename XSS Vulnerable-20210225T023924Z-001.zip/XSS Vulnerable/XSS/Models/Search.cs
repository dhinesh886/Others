﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XSS.Models
{
    public class Search
    {

        public string Query { get; set; }
        public string Result { get; set; }
    }
}
