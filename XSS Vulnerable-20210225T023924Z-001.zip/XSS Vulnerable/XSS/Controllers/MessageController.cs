﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using XSS.Models;

namespace XSS.Controllers
{
    public class MessageController : Controller
    {


        [Route("message/create")]
        public ViewResult CreateMessage(string message)
        {
            return View();
        }


        public ViewResult SaveMessage(Message objMessage)
        {
            int intStatus = new Message().SaveMessage(objMessage);
            if (intStatus == 1)
            {
                objMessage.SaveStatus = "Message Saved Successfully";
            }
            else
            {
                objMessage.SaveStatus = "Messged could not be Saved Successfully";
            }

            return View("SaveMessageStatus", objMessage);

        }


        [Route("admin/messages/{id}")]
        public ActionResult ViewMessage(string id = "0")
        {
            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(id);


           
            if (lstMessages.Count > 0)
                return View(lstMessages[0]);
            else
                return View(new List<Message>()); ;
            //Message objMessage = lstMessages[0];


        }

        public ActionResult PreviousMessage(Message msg)


        {
            int intMsgId = Convert.ToInt32(msg.Id);
            if (intMsgId == 0)
                intMsgId = 0;
            else
                intMsgId = intMsgId - 1;

            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(intMsgId.ToString());

           

            return View("ViewMessage", lstMessages[0]);
        }


        public ActionResult NextMessage(Message msg)


        {
            int intMsgId = Convert.ToInt32(msg.Id) + 1;

            string strMsgId = intMsgId.ToString();
            
            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(strMsgId);

            

            return View("ViewMessage", lstMessages[0]);



        }



        [Route("message/search")]

       // [Route("message/search/{q}")]
        public ViewResult SearchMessage(string q)
        {

            
            ViewData["searchstring"] = q;

            //get the list of messages
            List<Message> lstMessages = new Message().GetMessagesByUserName(q);

            Search objSearch = new Search();
            objSearch.Query = q;
            return View(lstMessages);
        }


       

        







        // GET: MessageController
        public ActionResult Index()
        {
            
            return View();
        }

        // GET: MessageController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: MessageController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MessageController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MessageController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: MessageController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MessageController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: MessageController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
