

CREATE PROCEDURE [dbo].[SP_AuthenticateUser]
	@username varchar(100),
	@password varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM login_details WHERE [username] = @username 
	AND [password]=@password;


END


