
CREATE PROCEDURE [dbo].[SP_SaveMessage]
	-- Add the parameters for the stored procedure here
	@name		varchar(50),
	@email		varchar(50),
	@message	varchar(100),
	@status		int OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	 SET @status=0;
INSERT INTO MessageDetails
           (name,email,message)
     VALUES
           (@name,@email,@message)

		   SET @status=1;

END


