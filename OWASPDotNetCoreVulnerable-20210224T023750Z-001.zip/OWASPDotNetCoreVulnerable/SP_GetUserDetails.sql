

CREATE PROCEDURE [dbo].[SP_GetUserDetails]
	@Id int
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM user_details WHERE id = @Id
END
GO

