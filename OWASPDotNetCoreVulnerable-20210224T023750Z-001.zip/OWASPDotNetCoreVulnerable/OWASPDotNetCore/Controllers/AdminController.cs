﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OWASPDotNetCore.Models;

namespace OWASPDotNetCore.Controllers
{
    public class AdminController : Controller
    {
        // GET: AdminController
        public ActionResult Index()
        {
            return View();
        }


        //[Route("admin/messages/{username}")]
        //public ActionResult ViewMessageByUsername(string username)
        //{
        //    List<Message> lstMessages = new List<Message>();
        //    if (username == "admin" || username.ToUpper() == "ALL")
        //        lstMessages = new Message().GetMessagesByUserName("ALL");
        //    else
        //        lstMessages = new Message().GetMessagesByUserName(username);

        //    //Message objMessage = lstMessages[0];

        //    return View(lstMessages[0]);
        //}


        //[Route("admin/messages/{id}")]
        [Route("admin/messages/{id}")]
        public ActionResult ViewMessage(string id="0")
        {
            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(id);
           

            //Message objMessage = lstMessages[0];

            return View(lstMessages[0]);
        }


        public ActionResult PreviousMessage(Message msg)


        {
            int intMsgId = Convert.ToInt32(msg.Id);
            if (intMsgId == 0)
                intMsgId = 0;
            else
                intMsgId = intMsgId - 1;
            
            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(intMsgId.ToString());


            //Message objMessage = lstMessages[0];

            return View("ViewMessage",lstMessages[0]);
        }

        
        public ActionResult NextMessage(Message msg)


        {
            int intMsgId = Convert.ToInt32(msg.Id) + 1;

            string strMsgId = intMsgId.ToString();
            //int MsgId = Convert.ToInt32(strMsgId);
            List<Message> lstMessages = new List<Message>();
            lstMessages = new Message().GetMessages(strMsgId);


            //Message objMessage = lstMessages[0];

            return View("ViewMessage",lstMessages[0]);
        }

        // GET: AdminController/Details/5
        //[Route("messages/admin")]
        //[Route("messages/{username}")]
        public ActionResult ViewMessage_del(string username)
        {
            List<Message> lstMessages = new List<Message>();
            if(username=="admin")
                lstMessages = new Message().GetMessages("ALL");
            else
                lstMessages = new Message().GetMessages(username);

            return View(lstMessages);
        }

        // GET: AdminController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AdminController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AdminController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

      

    }
}
