﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using OWASPDotNetCore.Models;
using Microsoft.Security.Application;
using System.Security.Claims;

namespace OWASPDotNetCore.Controllers
{
    public class AccountController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();

        //}

        private IConfiguration Configuration;

        public AccountController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        public string Index()
        {
            //return View();
            return "this is the account controller";


        }

        
        public ViewResult Login1()
        {
            //return View();
            return View();
        }

        [HttpGet]
        public ViewResult Login()
        {
            //return View();
            return View();
        }


        [HttpPost]
        public string Authenticate(string Username, string Password)
        {
            string strLoginStatus = "";

           

            int intAuthStatus = new User().AuthenticateUser(Username, Password);

                    if (intAuthStatus == 1)
                    {
                        strLoginStatus = "Authenticated as " + Username;


                    }

                    else
                    {
                        strLoginStatus = "Invalid Credentials";
                    }
               

           

           
            return strLoginStatus;
        }

        [HttpGet]
        [Route("userdetails/{username}")]
        public ViewResult UserDetails(string username)
        {
            List<User> lstUsers = new User().GetUserDetails(username);
           
            return View(lstUsers);
        }


       
       


    }
}
