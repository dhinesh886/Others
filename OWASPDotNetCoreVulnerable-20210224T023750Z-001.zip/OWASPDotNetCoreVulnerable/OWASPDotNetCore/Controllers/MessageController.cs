﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OWASPDotNetCore.Models;

namespace OWASPDotNetCore.Controllers
{
    public class MessageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        [Route("message/create")]
        public ViewResult CreateMessage(string message)
        {
            return View();
        }

        public ViewResult SaveMessage(Message objMessage)
        {
            int intStatus = new Message().SaveMessage(objMessage);
            if (intStatus == 1)
            {
                objMessage.SaveStatus = "Message Saved Successfully";
            }
            else
            {
                objMessage.SaveStatus = "Messged could not be Saved Successfully";
            }

            return View("SaveMessageStatus", objMessage);

        }
    }
}
