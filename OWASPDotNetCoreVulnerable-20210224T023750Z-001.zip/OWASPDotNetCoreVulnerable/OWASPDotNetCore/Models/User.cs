﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace OWASPDotNetCore.Models
{
    public class User
    {

        private static string strCon1 = "Server=.;Database=CORESecurity;Integrated Security = true";
        private static string strCon = "Data Source=(localdb)\\MSSQLLocalDB;Integrated Security = True";

        //public Login(IConfiguration _configuration)
        //{
        //    Configuration = _configuration;
        //}

        #region props

        public string FirstName { get; set; }

        public string LastName { get; set; }


        public string PAN { get; set; }

        public string City { get; set; }
        #endregion
        /// <summary>
        /// 
        /// </summary>




        public int ID { get; set; }
        
        public string Username { get; set; }

        
       
        public string Password { get; set; }

        public string Message { get; set; }



        //Insecure Code
        public int AuthenticateUser(string Username, string Password)
        {
            int intAuthStatus = 0;
            using (SqlConnection connection = new SqlConnection(strCon))
            {
                connection.Open();


                //Insecure Code
                // SqlCommand command = new SqlCommand($"SELECT * FROM user_details WHERE Id = {Request.Query["id"]}", connection);
                string strQuery = $"SELECT * FROM login_details WHERE username = '" + Username + "' AND password='" + Password + "'";
                SqlCommand command = new SqlCommand(strQuery, connection);
                //Insecure Code
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        intAuthStatus = 1;
                    }

                    else
                    {
                        intAuthStatus = 0;
                    }
                }
            }

            return intAuthStatus;
        }

      

        //Vulnerable Get User Details
        public List<User> GetUserDetails(string username)
        {
            List<User> lstUser = new List<User>();

            using (SqlConnection connection = new SqlConnection(strCon))
            {
                string strQuery = "";
                connection.Open();

                if(username.ToUpper()=="ALL")
                    strQuery = $"SELECT * FROM user_details";
                else
                    strQuery = $"SELECT * FROM user_details WHERE id = '" + username + "'";

                SqlCommand command = new SqlCommand(strQuery, connection);

                using (var reader = command.ExecuteReader())
                {
                    int i = 0;
                    while (reader.Read())
                    {
                        User objUser = new User();
                        string returnString = string.Empty;
                        objUser.FirstName = reader["firstname"].ToString();
                        objUser.LastName = reader["lastname"].ToString();
                        objUser.PAN = reader["pan"].ToString();
                        objUser.City = reader["city"].ToString();
                        //returnString += $"Name : {reader["Name"]}. ";
                        //returnString += $"Description : {reader["Description"]}";
                        lstUser.Add(objUser);
                    }
                   
                }
            }

            return lstUser;
        }



       

    }

}
